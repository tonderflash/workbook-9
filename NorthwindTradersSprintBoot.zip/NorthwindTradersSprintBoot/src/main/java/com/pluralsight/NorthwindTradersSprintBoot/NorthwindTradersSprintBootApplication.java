package com.pluralsight.NorthwindTradersSprintBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NorthwindTradersSprintBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(NorthwindTradersSprintBootApplication.class, args);
	}

}
